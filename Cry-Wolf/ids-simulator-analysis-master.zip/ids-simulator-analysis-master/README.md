# ids-simulator-analysis

## Prerequisites
```
    sudo apt update
    sudo apt install postgresql postgresql-contrib
    sudo -u postgres psql
    \password
    sudo -u postgres createdb crywolf
```